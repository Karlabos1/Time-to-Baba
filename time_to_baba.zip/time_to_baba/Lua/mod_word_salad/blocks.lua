-- OVERRIDE: keep karma when undoing destruction, ECHO interactions with BACK

--[[ @Merge: moveblock() was merged ]]



-- OVERRIDE: add ALIVE interactions with WIN/DEFEAT/etc., add karma for destructions by overlap or BOOM, implement REPENT, add special interaction for LEVEL IS ENTER

--[[ @Merge: block() was merged ]]



-- OVERRIDE: implement LEVEL IS ALIVE and LEVEL IS KARMA, add karma to level, implement LEVEL IS REPENT

--[[ @Merge: levelblock() was merged ]]



-- OVERRIDE: add checks for ALIVE

--[[ @Merge: findplayer() was merged ]]
