table.insert(editor_objlist_order, "text_alive")
editor_objlist["text_alive"] = 
{
    name = "text_alive",
    sprite_in_root = false,
    unittype = "text",
    tags = {"text","text_quality","word salad"},
    tiling = -1,
    type = 2,
    layer = 20,
    colour = {4, 0},
    colour_active = {4, 1},
}

table.insert(editor_objlist_order, "text_vessel")
editor_objlist["text_vessel"] = 
{
    name = "text_vessel",
    sprite_in_root = false,
    unittype = "text",
    tags = {"text","text_quality","movement","word salad"},
    tiling = -1,
    type = 2,
    layer = 20,
    colour = {1, 1},
    colour_active = {0, 1},
}

table.insert(editor_objlist_order, "text_vessel2")
editor_objlist["text_vessel2"] = 
{
    name = "text_vessel2",
    sprite_in_root = false,
    unittype = "text",
    tags = {"text","text_quality","movement","word salad"},
    tiling = -1,
    type = 2,
    layer = 20,
    colour = {1, 1},
    colour_active = {0, 1},
}

table.insert(editor_objlist_order, "text_hop")
editor_objlist["text_hop"] = 
{
    name = "text_hop",
    sprite_in_root = false,
    unittype = "text",
    tags = {"text","text_quality","movement","word salad"},
    tiling = -1,
    type = 2,
    layer = 20,
    colour = {4, 3},
    colour_active = {4, 4},
}

table.insert(editor_objlist_order, "text_hops")
editor_objlist["text_hops"] = 
{
    name = "text_hops",
    sprite_in_root = false,
    unittype = "text",
    tags = {"text","text_verb","movement","word salad"},
    tiling = -1,
    type = 1,
    layer = 20,
    colour = {4, 3},
    colour_active = {4, 4},
}

table.insert(editor_objlist_order, "text_karma")
editor_objlist["text_karma"] = 
{
    name = "text_karma",
    sprite_in_root = false,
    unittype = "text",
    tags = {"text","text_quality","word salad"},
    tiling = -1,
    type = 2,
    layer = 20,
    colour = {2, 1},
    colour_active = {2, 2},
}

table.insert(editor_objlist_order, "text_sinful")
editor_objlist["text_sinful"] = 
{
    name = "text_sinful",
    sprite_in_root = false,
    unittype = "text",
    tags = {"text","text_prefix","word salad"},
    tiling = -1,
    type = 3,
    layer = 20,
    colour = {2, 1},
    colour_active = {2, 2},
}

table.insert(editor_objlist_order, "text_repent")
editor_objlist["text_repent"] = 
{
    name = "text_repent",
    sprite_in_root = false,
    unittype = "text",
    tags = {"text","text_quality","word salad"},
    tiling = -1,
    type = 2,
    layer = 20,
    colour = {5, 1},
    colour_active = {5, 2},
}

table.insert(editor_objlist_order, "text_echo")
editor_objlist["text_echo"] = 
{
    name = "text_echo",
    sprite_in_root = false,
    unittype = "text",
    tags = {"text","text_quality","word salad"},
    tiling = -1,
    type = 2,
    layer = 20,
    colour = {0, 2},
    colour_active = {0, 3},
}

table.insert(editor_objlist_order, "text_enter")
editor_objlist["text_enter"] = 
{
    name = "text_enter",
    sprite_in_root = false,
    unittype = "text",
    tags = {"text","text_quality","word salad"},
    tiling = -1,
    type = 2,
    layer = 20,
    colour = {2, 3},
    colour_active = {2, 4},
}

table.insert(editor_objlist_order, "text_vehicle")
editor_objlist["text_vehicle"] = 
{
    name = "text_vehicle",
    sprite_in_root = false,
    unittype = "text",
    tags = {"text","text_quality","movement","word salad"},
    tiling = -1,
    type = 2,
    layer = 20,
    colour = {1, 1},
    colour_active = {0, 1},
}

formatobjlist()
