-- OVERRIDE: also check for ENTER

--[[ @Merge: mapcursor_load() was merged ]]


-- OVERRIDE: also check for ENTER

--[[ @Merge: mapcursor_idle() was merged ]]


-- OVERRIDE: add checks for ECHO when a cursor is moved, add support for VEHICLE

--[[ @Merge: mapcursor_move() was merged ]]


-- OVERRIDE: also check for ENTER

--[[ @Merge: mapcursor_enter() was merged ]]


-- OVERRIDE: also check for ENTER

--[[ @Merge: mapcursor_hardset() was merged ]]


-- OVERRIDE: also check for ENTER

--[[ @Merge: mapcursor_levelstart() was merged ]]


-- OVERRIDE: also check for ENTER

--[[ @Merge: mapcursor_displayname() was merged ]]


-- OVERRIDE: also check for ENTER

--[[ @Merge: idleblockcheck() was merged ]]


-- OVERRIDE: also check for ENTER

--[[ @Merge: cursorcheck() was merged ]]


-- OVERRIDE: also check for ENTER

--[[ @Merge: mapcursor_tofront() was merged ]]


-- OVERRIDE: also check for ENTER

--[[ @Merge: hidecursor() was merged ]]


-- OVERRIDE: also check for ENTER

--[[ @Merge: mapcursor_setonlevel() was merged ]]
