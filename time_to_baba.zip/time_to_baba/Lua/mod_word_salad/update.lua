-- EDIT: Update when something happens to ECHO units

--[[ @Merge: doupdate() was merged ]]
