-- OVERRIDE: Add check for ALIVE

--[[ @Merge: isgone() was merged ]]


-- OVERRIDE: keep karma after undoing

--[[ @Merge: delete() was merged ]]


-- OVERRIDE: update code if new unit is "ECHO"

--[[ @Merge: create() was merged ]]


-- OVERRIDE: check for code updates if ECHO is present

--[[ @Merge: update() was merged ]]


-- OVERRIDE: keep track of any text at the level position (including the level itself if it was converted) - This probably doesn't work with levels within levels
-- Also keep track of whether the level was sinful when entering

--[[ @Merge: getlevelsurrounds() was merged ]]


-- OVERRIDE: also keep track of ECHO units

--[[ @Merge: delunit() was merged ]]
