-- OVERRIDE: add check for ECHO

--[[ @Merge: conversion() was merged ]]


-- OVERRIDE: also check for ENTER

--[[ @Merge: convert() was merged ]]


-- OVERRIDE: keep karma after a conversion, add check for ECHO

--[[ @Merge: doconvert() was merged ]]
