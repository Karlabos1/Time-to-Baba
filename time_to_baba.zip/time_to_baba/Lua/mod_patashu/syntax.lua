
--[[ @Merge: addunit() was merged ]]



--[[ @Merge: cleanup() was merged ]]



--[[ @Merge: command() was merged ]]



--[[ @Merge: command_auto() was merged ]]



--[[ @Merge: dolog() was merged ]]



--[[ @Merge: createall() was merged ]]



--[[ @Merge: setunitmap() was merged ]]



--[[ @Merge: setundo() was merged ]]



--[[ @Merge: victory() was merged ]]



--[[ @Merge: poscorrect() was merged ]]



--[[ @Merge: stringintable() was merged ]]



--[[ @Merge: levelborder() was merged ]]



--[[ @Merge: updatescreen() was merged ]]



--[[ @Merge: updateroomsize() was merged ]]



--[[ @Merge: checkerasesafety() was merged ]]



--[[ @Merge: fixedrandom() was merged ]]



--[[ @Merge: setfixedrandom() was merged ]]



--[[ @Merge: overrideundoseeding() was merged ]]



--[[ @Merge: setseedingtype() was merged ]]



--[[ @Merge: generatefreqs() was merged ]]



--[[ @Merge: setupnounlists() was merged ]]



--[[ @Merge: update_cleanup() was merged ]]
