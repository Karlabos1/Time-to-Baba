
--[[ @Merge: mapcursor_move() was merged ]]


