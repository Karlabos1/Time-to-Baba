-- @mods(THIS) - the reason we override these condition functions is to support infix conditions with THIS, like "baba on THIS is green".
-- Its unfortunate, but there currently isn't any "conditional parameters"


--[[ @Merge: condlist.on() was merged ]]



--[[ @Merge: condlist.near() was merged ]]



--[[ @Merge: condlist.nextto() was merged ]]



--[[ @Merge: condlist.facing() was merged ]]



--[[ @Merge: condlist.seeing() was merged ]]



--[[ @Merge: condlist.without() was merged ]]


--[[ @Merge: condlist.above() was merged ]]



--[[ @Merge: condlist.below() was merged ]]



--[[ @Merge: condlist.besideright() was merged ]]



--[[ @Merge: condlist.besideleft() was merged ]]



--[[ @Merge: condlist.feeling() was merged ]]
