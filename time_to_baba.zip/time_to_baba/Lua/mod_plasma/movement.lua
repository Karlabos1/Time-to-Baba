
--[[ @Merge: movecommand() was merged ]]



--[[ @Merge: move() was merged ]]



--[[ @Merge: check() was merged ]]



--[[ @Merge: dopush() was merged ]]


