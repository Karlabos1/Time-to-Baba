
--[[ @Merge: editor_currobjlist_add() was merged ]]
