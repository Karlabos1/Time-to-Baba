
--[[ @Merge: codecheck() was merged ]]



--[[ @Merge: calculatesentences() was merged ]]



--[[ @Merge: docode() was merged ]]



--[[ @Merge: addoption() was merged ]]



--[[ @Merge: code() was merged ]]



--[[ @Merge: findwordunits() was merged ]]



--[[ @Merge: postrules() was merged ]]



--[[ @Merge: subrules() was merged ]]
