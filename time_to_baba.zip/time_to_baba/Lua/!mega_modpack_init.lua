PF_MEGA_MODPACK_INITIALIZED = true

-- These are initialized in the respective modpacks
-- table.insert(objlistdata.alltags, "plasma's mods")
-- table.insert(objlistdata.alltags, "patashu")

table.insert(objlistdata.alltags, "stringwords")
table.insert(objlistdata.alltags, "word salad")
table.insert(objlistdata.alltags, "past")
table.insert(objlistdata.alltags, "persist")
table.insert(objlistdata.alltags, "btd456creeper mods")
table.insert(objlistdata.alltags, "local mod")
